
  <?php include_once 'layout/script_atas.php'?>
  <?php include_once 'layout/aside.php'?>
  <main class="main-content position-relative border-radius-lg ">
    <?php include_once 'layout/nav.php'?>
    <?php include_once 'pages/main.php'?>
    <?php include_once 'layout/footer.php'?>
  </main>
  <?php include_once 'layout/setting.php'?>
  <?php include_once 'layout/script_bawah.php'?>
 
  