    <footer class="footer p-3">
        <div class="container-fluid">
          <div class="row align-items-center justify-content-lg-between">
            <div class="col-lg-6 mb-lg-0 mb-4">
              <div class="copyright text-center text-sm text-muted text-lg-start">
                © <script>
                  document.write(new Date().getFullYear())
                </script>,
                made with <i class="fa fa-heart text-danger"></i> by
                <a href="#" class="font-weight-bold" >Abdul Aziz</a>
                for a better web.
              </div>
            </div>
            <div class="col-lg-6">
              <ul class="nav nav-footer justify-content-center justify-content-lg-end">
                <li class="nav-item">
                  <a href="#" class="nav-link text-muted" >Abdul Aziz</a>
                </li>
                <li class="nav-item">
                  <a href="index.php?hal=profile" class="nav-link text-muted" >About Us</a>
                </li>
                <li class="nav-item">
                  <a href="index.php?hal=pendidikan" class="nav-link text-muted" >Education</a>
                </li>
                <li class="nav-item">
                  <a href="index.php?hal=contact" class="nav-link pe-0 text-muted" >Contact</a>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </footer>