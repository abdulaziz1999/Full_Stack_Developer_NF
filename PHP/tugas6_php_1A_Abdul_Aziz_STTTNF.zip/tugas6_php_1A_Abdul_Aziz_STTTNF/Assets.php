<?php 
    class Assets{
        public $no;
        public $nama;
        public $tahun;
        public $nilai;

        public function __construct($no,$nama, $tahun, $nilai){
            $this->no = $no;
            $this->nama = $nama;
            $this->tahun = $tahun;
            $this->nilai = $nilai;
        }
        
        public function cetak($ket){
            echo "<td>$this->no</td>
                    <td>$this->nama</td>
                    <td>$this->tahun</td>
                    <td>$ket</td>
                    <td>".$this->rupiah()."</td>";
        }

        function rupiah(){
            return "Rp. ".number_format($this->nilai, 0, ',', '.');
        }
    }