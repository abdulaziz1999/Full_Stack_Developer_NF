<div class="col-md-3">
    <ul class="list-group">
        <li class="list-group-item active" aria-current="true">Social Media</li>
        <a href="https://twitter.com/AbdulAz65072470" class="list-group-item list-group-item-action"><i class="bx bxl-twitter"></i> Twitter</a>
        <a href="https://www.facebook.com/aziz.revolusion" class="list-group-item list-group-item-action"><i class="bx bxl-facebook"></i> Facebook</a>
        <a href="https://instagram.com/azizakbarpermana" class="list-group-item list-group-item-action"><i class="bx bxl-instagram"></i> Instagram</a>
        <a href="https://aziz212.medium.com" class="list-group-item list-group-item-action"><i class="bx bxl-medium"></i> Medium</a>
        <a href="https://www.linkedin.com/in/abdul-aziz-9a64711a7" class="list-group-item list-group-item-action"><i class="bx bxl-linkedin"></i> Linkedin</a>
    </ul>
</div>
</div>