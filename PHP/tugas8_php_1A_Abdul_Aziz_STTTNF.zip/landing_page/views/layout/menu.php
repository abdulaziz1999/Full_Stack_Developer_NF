<div class="row">
    <div class="col-md-12">
        <!-------awal menu----------->
        <nav class="navbar navbar-expand-lg navbar-dark bg-primary">
            <a class="navbar-brand" href="index.php">Profile</a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent"
                aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>

            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav mr-auto">
                    <li class="nav-item <?=$_GET['hal'] == 'home' || $_GET['hal'] == '' ? 'active' : '' ?>">
                        <a class="nav-link" href="index.php?hal=home">Home</a>
                    </li>
                    <li class="nav-item <?=$_GET['hal'] == 'aboutus' ? 'active' : '' ?>">
                        <a class="nav-link" href="index.php?hal=aboutus">About</a>
                    </li>
                    <li class="nav-item <?=$_GET['hal'] == 'gallery' ? 'active' : '' ?>">
                        <a class="nav-link" href="index.php?hal=gallery">Gallery</a>
                    </li>
                    <li class="nav-item <?=$_GET['hal'] == 'pendidikan' ? 'active' : '' ?>">
                        <a class="nav-link" href="index.php?hal=pendidikan">Pendidikan</a>
                    </li>
                    <li class="nav-item <?=$_GET['hal'] == 'contact' ? 'active' : '' ?>">
                        <a class="nav-link" href="index.php?hal=contact">Contact</a>
                    </li>
                </ul>
                <form class="form-inline my-2 my-lg-0">
                    <input class="form-control mr-sm-2" type="search" placeholder="Search" aria-label="Search">
                    <button class="btn btn-outline-success my-2 my-sm-0" type="submit">Search</button>
                </form>
            </div>
        </nav>
        <!--------akhir menu---------->
    </div>
</div>