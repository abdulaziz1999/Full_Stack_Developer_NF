<!-- card 404 not found-->
<div class="card">
    <h5 class="card-header bg-primary text-white text-center">404 Not Found</h5>
    <div class="card-body">
        <div class="col-md-12 pb-5 text-center">
            <h1>404</h1>
            <h3>Page Not Found</h3>
            <p>The page you are looking for might have been removed, had its name changed, or is temporarily unavailable.</p>
            <a href="index.php?hal=home" class="btn btn-primary">Back to Home</a>
        </div>
    </div>
</div>
