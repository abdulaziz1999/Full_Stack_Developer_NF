<div class="jumbotron">
    <h1 class="display-4">Welcome to Profile</h1>
    <p class="lead">Hallo My Name is Abdul Aziz I'am Full Stack Web Developer</p>
    <hr class="my-4">
    <a class="btn btn-primary btn-lg" href="index.php?hal=about" role="button">Read</a>
</div>