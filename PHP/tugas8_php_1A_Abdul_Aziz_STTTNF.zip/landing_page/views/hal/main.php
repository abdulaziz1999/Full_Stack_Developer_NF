<div class="row">
    <div class="col-md-9">
        <?php
        @$hal = $_REQUEST['hal'];
        if($hal == 'aboutus' || $hal == 'gallery' || $hal == 'pendidikan' || $hal == 'contact' || $hal == 'home'){
          include_once $hal.'.php';
        }elseif(!isset($hal)){
          include_once 'home.php';
        }else{
          include_once '404.php';
        }
        ?>
    </div>