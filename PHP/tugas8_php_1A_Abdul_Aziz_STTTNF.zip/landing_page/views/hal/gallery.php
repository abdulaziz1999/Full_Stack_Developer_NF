<div class="card">
    <h5 class="card-header bg-primary text-white">Gallery</h5>
    <div class="card-body">
        <div class="row">
            <div class="col-md-3">
                <div class="card" style="width: 18rem;">
                    <img src="https://abdulaziz1999.github.io/assets/img/portfolio/p12.png" class="card-img-top"
                        alt="...">
                    <div class="card-body">
                        <h5 class="card-title">Website PPDB</h5>
                        <p class="card-text">Depok</p>
                        <a href="#" class="btn btn-primary">Read <i class='bx bx-right-arrow-alt'></i></a>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card" style="width: 18rem;">
                    <img src="https://abdulaziz1999.github.io/assets/img/portfolio/p2.png" class="card-img-top"
                        alt="...">
                    <div class="card-body">
                        <h5 class="card-title">Website PSB DQM</h5>
                        <p class="card-text">Depok</p>
                        <a href="#" class="btn btn-primary">Read <i class='bx bx-right-arrow-alt'></i></a>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card" style="width: 18rem;">
                    <img src="https://abdulaziz1999.github.io/assets/img/portfolio/p13.png" class="card-img-top"
                        alt="...">
                    <div class="card-body">
                        <h5 class="card-title">Website SMA N 1 Sekayam</h5>
                        <p class="card-text">Depok</p>
                        <a href="#" class="btn btn-primary">Read <i class='bx bx-right-arrow-alt'></i></a>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card" style="width: 18rem;">
                    <img src="https://abdulaziz1999.github.io/assets/img/portfolio/p9.png" class="card-img-top"
                        alt="...">
                    <div class="card-body">
                        <h5 class="card-title">Website Depok</h5>
                        <p class="card-text">Depok</p>
                        <a href="#" class="btn btn-primary">Read <i class='bx bx-right-arrow-alt'></i></a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>