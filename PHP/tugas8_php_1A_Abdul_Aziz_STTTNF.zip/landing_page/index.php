<?php
include_once 'views/layout/kode_atas.php';
include_once 'views/layout/header.php';
include_once 'views/layout/menu.php';
echo '<br/>';
include_once 'views/hal/main.php';
include_once 'views/layout/sidebar.php';
echo '<br/>';
include_once 'views/layout/footer.php';
include_once 'views/layout/kode_bawah.php';