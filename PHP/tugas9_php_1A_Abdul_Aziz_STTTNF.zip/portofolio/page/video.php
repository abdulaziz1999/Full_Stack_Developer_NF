    <section id="video" class="education">
      <div class="container" data-aos="fade-up">
        <div class="row">
          <div class="section-title">
            <h2>Video</h2>
          </div>
          <div class="col-lg-4 text-center">
            <h5><b>SMA Negeri 1 Sekayam</b></h5>
            <div class="ignielYTlazy rounded-3" data-embed="0GcWnatlv3c">
              <span class="button"></span>
            </div>
          </div>
          <div class="col-lg-4 text-center">
            <h5><b>Pesantren PeTIK</b></h5>
            <div class="ignielYTlazy rounded-3" data-embed="PRcQpTdLmjg">
              <span class="button"></span>
            </div>
          </div>
          <div class="col-lg-4 text-center">
            <h5><b>STT Terpadu Nurul Fikri</b></h5>
            <div class="ignielYTlazy rounded-3" data-embed="eZk9rvx9JAI">
              <span class="button"></span>
            </div>
          </div>
        </div>

      </div>
    </section>