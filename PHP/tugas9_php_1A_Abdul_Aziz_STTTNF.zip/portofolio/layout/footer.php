    <footer id="footer">
        <div class="container">
        <h3>Abdul Aziz</h3>
        <p>"Be a Beneficial Person for Others".</p>
        <div class="social-links">
            <a href="https://twitter.com/AbdulAz65072470" class="twitter"><i class="bx bxl-twitter"></i></a>
            <a href="https://www.facebook.com/aziz.revolusion" class="facebook"><i class="bx bxl-facebook"></i></a>
            <a href="https://instagram.com/azizakbarpermana" class="instagram"><i class="bx bxl-instagram"></i></a>
            <a href="https://aziz212.medium.com" class="medium"><i class="bx bxl-medium"></i></a>
            <a href="https://www.linkedin.com/in/abdul-aziz-9a64711a7" class="linkedin"><i class="bx bxl-linkedin"></i></a>
        </div>
        <div class="copyright">
            &copy; Copyright <strong><span>A212 Official</span></strong>. All Rights Reserved
        </div>
        <div class="credits">
        </div>
        </div>
    </footer>